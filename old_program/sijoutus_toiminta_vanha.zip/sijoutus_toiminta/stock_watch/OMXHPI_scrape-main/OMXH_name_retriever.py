import datetime as dt
import pandas as pd

import concurrent.futures as cf
from yahoofinancials import YahooFinancials

import re
import ast
import time
import requests
from bs4 import BeautifulSoup
from selenium import webdriver

omx_h = 'https://www.kauppalehti.fi/porssi/kurssit/XHEL'

# header = {
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36',
# }

header = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36',
}

OMXH = []
#res = requests.get(omx_h, headers=header)

# Use Selenium to automate browser actions
driver = webdriver.Chrome()  # Replace if using other than Chrome
driver.get(omx_h)  

# Define the amount of scrolling and the number of iterations
scroll_pixels = 2000  # Adjust if needed
scroll_iterations = 5  # Adjust if needed

# Scroll down multiple times to fetch more content
for i in range(scroll_iterations):
    driver.execute_script(f"window.scrollBy(0, {scroll_pixels});")
    driver.implicitly_wait(1)  # Wait for 1 second between each scroll iteration

# Extract the complete page source
page_source = driver.page_source

# Parse the page source with Beautiful Soup
soup = BeautifulSoup(page_source, "html.parser")

# Close the browser
driver.quit()

divs = soup.findAll('a', {"class": ["tmcl-__sc-18ro7st-3 suYgN", "tmcl-__sc-18ro7st-3 gFUoDG"]})

# print(divs)
#print(soup.prettify())

OMXH = []

for i, val in enumerate(divs):
    ticker = re.findall(r'/osake/.*["]\s', str(val))[0]   # Find the part of the url after '/osake/' since this contains the ticker.
    ticker = str(ticker).replace('/osake/', '').replace('"', '').strip()    # Delete all the leftovers around the ticker
    name = re.findall(r'>[^><]+[öäå]*<', str(val))[0]   # Same for the company names
    name = str(name).replace('>', '').replace('<', '').strip()
    OMXH.append(ticker)
    

# print(OMXH)
# print(len(OMXH))


stocks = [stock + '.HE' for stock in OMXH]
stocks_set = set(stocks)

contains_duplicates = len(stocks) != len(stocks_set)
if contains_duplicates:
    print('Stock list contains duplicates!')

print(stocks)

balanceSheet = {}       #
incomeStatement = {}    #
cashStatement = {}      #

def retrieve_stock_data(stock):

    try:
        print(stock)
        yahoo_financials = YahooFinancials(stock)
        balance_sheet_data = yahoo_financials.get_financial_stmts('annual', 'balance')
        income_sheet_data = yahoo_financials.get_financial_stmts('annual', 'income')
        cash_sheet_data = yahoo_financials.get_financial_stmts('annual', 'cash')
        # print(balance_sheet_data)

        balanceSheet[stock] = balance_sheet_data['balanceSheetHistory'][stock]
        incomeStatement[stock] = income_sheet_data['incomeStatementHistory'][stock]
        cashStatement[stock] = cash_sheet_data['cashflowStatementHistory'][stock]
    except:
        print('Error retrieving stock data for {stock}')

    return      


start = time.time()

executor = cf.ThreadPoolExecutor(16)

futures = [executor.submit(retrieve_stock_data, stock) for stock in stocks]
cf.wait(futures)

end = time.time()
print(f'Time taken: {end-start}s')

# Save FY data to file 

with open('balanceSheet_OMXH.txt', 'w') as output:
    output.write(str(balanceSheet))
with open('incomeStatement_OMXH.txt', 'w') as output:
    output.write(str(incomeStatement))
with open('cashStatement_OMXH.txt', 'w') as output:
    output.write(str(cashStatement))

print('Done!')